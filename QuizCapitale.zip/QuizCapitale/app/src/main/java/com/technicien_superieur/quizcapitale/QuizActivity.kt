package com.technicien_superieur.quizcapitale

import android.content.DialogInterface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog



class QuizActivity : AppCompatActivity() {
    
    var quizs = ArrayList<Quiz>()
    var numberOfGoodAnswers : Int = 0
    var currentQuizIndex : Int = 0
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)
        
        quizs.add(Quiz("Quel est la capitale de l'Algérie ?", "Alger", "Paris", "Marseille", 1))
        quizs.add(Quiz("Quel est le 6ème Président de la Vème République française ?", "Jacques Chirac", "Nicolas Sarkory", "Emmanuel Macron", 2))
        quizs.add(Quiz("Quel est, à ce jour, la plus grande catastrophe nucléaire de l'histoire de l'humanité ?", "Fukushima", "Tricastin", "Tchernobyl", 3))
        quizs.add(Quiz("Quel film détient aujourd'hui le plus gros succès mondial au box office ?", "Avatar", "Avengers : Endgame", "Titanic", 1))
        quizs.add(Quiz("Quel est la capitale économique de la Suisse ?", "Berne", "Zurich", "Genève", 2))
        quizs.add(Quiz("Quel chanteur ou chanteuse est l'interprète de 'Shape of You', sorti en 2017 ?", "Adèle", "Drake", "Ed Sheeran", 3))
        quizs.add(Quiz("Comment surnomme-t-on la première femme préhistorique ?", "Lucy", "Mary", "La Dame de Flores", 1))
        quizs.add(Quiz("A quel peintre attribue-t-on l'Origine du Monde ?", "Manet", "Gustave Courbet", "Monet", 2))
        quizs.add(Quiz("Quel célèbre réseau social fut crée par Evan Spiegel, Bobby Murphy et Reggie Brown ?", "Facebook", "TikTok", "Snapchat", 3))
        quizs.add(Quiz("Quel animal tue le plus d'hommes chaque année ?", "Le moustique", "Le chien", "Le requin", 1))
        quizs.add(Quiz("Quel cérémonie récompense le monde de la musique aux USA ?", "Les Golden Globes", "Les Baftas", "Les Grammy Awards", 3))
        quizs.add(Quiz("Au football, qui est le meilleur buteur de tous les temps ?", "Josef Bican", "Christiano Ronaldo", "Pelé", 1))
        quizs.add(Quiz("Quelle est la capitale du Costa Rica ?", "Tegucigalpa", "San José", "Managua", 2))
        quizs.add(Quiz("Quelles lignes imaginaires relient les pôles entre eux ?", "Les méridiens", "Les hémisphères", "Les parallèles", 1))
        quizs.add(Quiz("L'éreutophobie est la peur... ", "de dormir", "d'être érudit", "de rougir", 3))
        quizs.add(Quiz("Qu'est-ce qu'un 'troll' sur les réseaux sociaux ?", "Un pirate informatique", "Une victime de harcèlement", "Quelqu'un qui crée volontairement une polémique", 3))
        quizs.add(Quiz("Quels sont les deux archipels du Portugal ?", "Les canaries et les Açores", "Les Açores et Madère", "Les îles du Cap-Vert et Madère", 2))
        quizs.add(Quiz("Quelle est la première expédition a avoir fait le tour du monde à la voile ?", "Christophe Colomb", "Marco Polo", "Fernand Magellan", 3))
















        showQuestion(quizs.get(currentQuizIndex))
    }
    
    fun showQuestion(quiz : Quiz) {
        answer1.setText(quiz.answer1)
        answer2.setText(quiz.answer2)
        answer3.setText(quiz.answer3)
    }

    fun handleAnswer(answerID: Int) {
        val quiz = quizs.get(currentQuizIndex)

        if (quiz.isCorrect(answerID)) {
            numberOfGoodAnswers++
            Toast.makeText(this, "+1", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "+0", Toast.LENGTH_SHORT).show()
        }

        currentQuizIndex++

        if (currentQuizIndex >= quizs.size) {

            var alert = AlertDialog.Builder(this)
            alert.setTitle("Partie terminé !")
            alert.setMessage("Tu as eu " + numberOfGoodAnswers + " bonne(s) réponse(s)")
            alert.setPositiveButton("OK") { dialogInterface : DialogInterface?, i : Int ->
                finish()
            }
            alert.show()


        } else {
            showQuestion(quizs.get(currentQuizIndex))
        }
    }

    fun onClickAnswerOne(view : View) {
       handleAnswer(1)
    }

    fun onClickAnswerTwo(view : View) {
        handleAnswer(2)
    }

    fun onClickAnswerThree(view : View) {
        handleAnswer(3)
    }
    
}